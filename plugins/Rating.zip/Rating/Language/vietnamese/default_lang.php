<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["list_criteria_category"] = "Danh Sách Tiêu Chí Đánh Giá";
$lang["list_criteria"] = "Danh sách tiêu chí đánh giá";
$lang["Rating"] = "Chấm Điểm Nhân Viên";

return $lang;
