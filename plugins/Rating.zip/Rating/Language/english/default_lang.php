<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["list_criteria_category"] = "List Category Evaluation";
$lang["list_criteria"] = "List Of Evaluation Criteria";
$lang["Rating"] ="Rating Employee";

return $lang;
